export default function Faltas() {
    return(
        <>
        <div></div>
        </>
    )
}